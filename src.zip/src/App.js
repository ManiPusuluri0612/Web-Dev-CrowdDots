import './App.css'
import Home from './Home'
function App() {
  return (
    <div className="App">
      <h1>Hello world!</h1>
      <Home/>
    </div>
  )
}

export default App
